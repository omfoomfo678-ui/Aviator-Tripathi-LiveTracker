package com.example.aviatortracker

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val busy = AtomicBoolean(false)
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var lastSignature = ""

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(7, notification())
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        val dm = resources.displayMetrics
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay("AviatorOCR", dm.widthPixels, dm.heightPixels,
            dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, handler)
        handler.post(poll)
        return START_STICKY
    }

    private val poll = object : Runnable {
        override fun run() {
            val img = reader?.acquireLatestImage()
            if (img != null && busy.compareAndSet(false, true)) {
                try {
                    val plane = img.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * img.width
                    val bmp = Bitmap.createBitmap(img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(buffer)
                    val cropped = Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
                    bmp.recycle()
                    val input = InputImage.fromBitmap(cropped, 0)
                    recognizer.process(input)
                        .addOnSuccessListener { result ->
                            val lines = result.textBlocks.flatMap { it.lines }.map { it.text.trim() }
                            // Broad OCR pass: captures multiplier-like strings visible anywhere.
                            // User should keep the history strip visible; false positives are possible.
                            val signature = lines.joinToString("|")
                            if (signature != lastSignature) {
                                lastSignature = signature
                                val regex = Regex("(?i)([0-9]{1,4}(?:\\.[0-9]{1,2})?)\\s*[x×]")
                                val matches = regex.findAll(result.text).mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()
                                // Store the first newly detected multiplier only; full round ordering requires site-specific validation.
                                matches.lastOrNull()?.let { Store.add(this, it, result.text.take(500)) }
                            }
                        }
                        .addOnCompleteListener { cropped.recycle(); busy.set(false) }
                } catch (_: Exception) { img.close(); busy.set(false) }
                img.close()
            }
            handler.postDelayed(this, 2500)
        }
    }

    private fun notification(): Notification {
        val channel = "aviator_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(channel, "Aviator screen tracking", NotificationManager.IMPORTANCE_LOW))
        }
        return if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channel).setContentTitle("Aviator Tracker running")
                .setContentText("Reading visible screen for multiplier text").setSmallIcon(android.R.drawable.ic_menu_view).build()
        else Notification.Builder(this).setContentTitle("Aviator Tracker running")
            .setContentText("Reading visible screen").setSmallIcon(android.R.drawable.ic_menu_view).build()
    }

    override fun onDestroy() {
        handler.removeCallbacks(poll)
        display?.release(); reader?.close(); projection?.stop()
        recognizer.close()
        super.onDestroy()
    }
}
