package com.example.aviatortracker

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val requestCapture = 41
    private lateinit var summary: TextView
    private lateinit var history: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply {
            text = "AVIATOR LIVE TRACKER\nScreen-reading prototype • Android"
            textSize = 20f
        })
        root.addView(TextView(this).apply {
            text = "Start monitoring asks Android for screen-capture permission. Only visible screen content is read."
            textSize = 14f
        })
        root.addView(Button(this).apply {
            text = "Start screen tracking"
            setOnClickListener {
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
            }
        })
        root.addView(Button(this).apply {
            text = "Stop tracking"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)); refresh() }
        })
        root.addView(Button(this).apply {
            text = "Refresh report"
            setOnClickListener { refresh() }
        })
        root.addView(Button(this).apply {
            text = "Export CSV"
            setOnClickListener { exportCsv() }
        })
        summary = TextView(this).apply { textSize = 16f; setPadding(0, 20, 0, 12) }
        history = TextView(this).apply { textSize = 13f }
        root.addView(summary); root.addView(history)
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    @Deprecated("Deprecated in Android API but available for this target")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val svc = Intent(this, CaptureService::class.java)
            svc.putExtra("resultCode", resultCode)
            svc.putExtra("data", data)
            ContextCompat.startForegroundService(this, svc)
            Toast.makeText(this, "Tracking started. Keep Aviator visible.", Toast.LENGTH_LONG).show()
        }
    }

    private fun refresh() {
        val rows = Store.read(this)
        val counts = linkedMapOf<String, Int>()
        rows.forEach { r ->
            val v = r.optDouble("value", 0.0)
            listOf(3,5,8,9,10,15,30,50,100,200).forEach { threshold ->
                if (v >= threshold) counts["${threshold}x+"] = (counts["${threshold}x+"] ?: 0) + 1
            }
        }
        summary.text = "Captured rounds: ${rows.length()}\n" +
            counts.entries.joinToString("   ") { "${it.key}: ${it.value}" } +
            "\n\nNote: OCR may miss or misread values; verify against game history."
        history.text = (0 until minOf(rows.length(), 80)).joinToString("\n") { i ->
            val r = rows.getJSONObject(rows.length() - 1 - i)
            "${r.optString("time")}   ${r.optString("raw")}   (${r.optString("source")})"
        }.ifEmpty { "No rounds recorded yet." }
    }

    private fun exportCsv() {
        val rows = Store.read(this)
        val lines = mutableListOf("time,multiplier,raw")
        for (i in 0 until rows.length()) {
            val r = rows.getJSONObject(i)
            lines.add("\"${r.optString("time")}\",${r.optDouble("value")},\"${r.optString("raw").replace("\"", "'")}\"")
        }
        val text = lines.joinToString("\n")
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"; putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, "Share tracker CSV"))
    }
}
