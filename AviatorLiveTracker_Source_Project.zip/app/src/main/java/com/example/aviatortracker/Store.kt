package com.example.aviatortracker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Store {
    private const val PREF = "aviator_records"
    fun read(c: Context): JSONArray = try {
        JSONArray(c.getSharedPreferences(PREF, 0).getString("rows", "[]"))
    } catch (_: Exception) { JSONArray() }

    @Synchronized fun add(c: Context, value: Double, raw: String) {
        val rows = read(c)
        // Keep the full exact multiplier as a separate record; suppress only immediate duplicate OCR frames.
        val now = System.currentTimeMillis()
        if (rows.length() > 0) {
            val last = rows.getJSONObject(rows.length() - 1)
            if (last.optDouble("value") == value && now - last.optLong("ts") < 12000) return
        }
        rows.put(JSONObject().apply {
            put("value", value); put("raw", raw)
            put("ts", now)
            put("time", SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(now)))
            put("source", "screen OCR")
        })
        c.getSharedPreferences(PREF, 0).edit().putString("rows", rows.toString()).apply()
    }
}
