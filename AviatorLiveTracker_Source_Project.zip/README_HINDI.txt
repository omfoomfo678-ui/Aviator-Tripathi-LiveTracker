AVIATOR LIVE TRACKER — ANDROID SOURCE PROTOTYPE

महत्वपूर्ण:
यह अभी तैयार APK नहीं है। यह Android Studio source project/prototype है।
इसे build करके असली Cricbet99 स्क्रीन पर टेस्ट करना जरूरी है।

यह कैसे काम करता है:
1. Android MediaProjection से स्क्रीन कैप्चर की अनुमति माँगता है।
2. Google ML Kit OCR स्क्रीन पर दिख रहे टेक्स्ट में multiplier-जैसे नंबर खोजता है।
3. रिकॉर्ड फोन में सेव करता है और CSV साझा कर सकता है।

सीमाएँ:
- यह prototype स्क्रीन के पूरे टेक्स्ट को पढ़ता है; Cricbet99 के ऊपर-दाएँ history strip के लिए crop/position calibration अभी नहीं है।
- OCR गलत नंबर पढ़ सकता है, छूटे हुए राउंड या duplicate भी हो सकते हैं।
- वर्तमान deduplication केवल पास-पास के समान OCR परिणामों को रोकने का सरल उपाय है; यह production-grade round identity नहीं है।
- 30-item moving history से सही नए राउंड निकालने के लिए वास्तविक स्क्रीन layout पर परीक्षण और sequence-diff logic जरूरी है।
- यह अगले multiplier की भविष्यवाणी नहीं करता और जीत की गारंटी नहीं देता।
- स्क्रीन कैप्चर शुरू करने पर Android का persistent notification दिखेगा। इसे छिपाकर या बिना अनुमति चलाने का प्रयास नहीं करता।
- गेम का पासवर्ड/OTP कभी इस ऐप में न डालें।

Build:
Android Studio में इस folder को Open करें, Gradle sync करें, फिर Build > Build APK(s).
Android Studio/Gradle के लिए इंटरनेट और compatible JDK की जरूरत हो सकती है।
